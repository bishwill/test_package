def add_two(num):
    return num + 2