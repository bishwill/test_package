def add_one(number):
    return number + 1


def filepath():
    return __file__